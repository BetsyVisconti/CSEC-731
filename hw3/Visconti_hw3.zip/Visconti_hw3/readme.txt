Title:
Assigment 3: Building a Web Serer

Author:
Betsy Visconti (bjv4607@rit.edu)

Description:
Assignment 3 is a Python-based program that acts as a basic web server

Prerequesites:
This project requires Python 3 and should be run with administrator privilages  

Usage:
To run this program, it is necessary to run it through the command line. 
The program should be run by typing 'python3 hw3.py' followed by the IP Adress and port. 
Example: 'python3 hw1.py 127.0.0.1 9999





