Title:
Assigment 2: HTTP Parser

Author:
Betsy Visconti (bjv4607@rit.edu)

Description:
Assignment 2 is a Python-based program that parses HTTP Requests and outputs appropriate responses

Prerequesites:
This project requires Python 3 and a normal user account. 

Usage:
To run this program, it is necessary to run it through the command line. 
The program should be run by typing 'python3 hw2.py' followed by a file with an HTTP request. 
A demo text file was included, however it will work with any file.
Example: 'python3 hw1.py demo.txt





