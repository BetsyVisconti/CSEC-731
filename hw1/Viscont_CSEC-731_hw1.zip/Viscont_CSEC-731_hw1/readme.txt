Title:
Assigment 1: Building an HTTP Client

Author:
Betsy Visconti (bjv4607@rit.edu)

Description:
Assignment 1 is a Python-based program using sockets and parsing to return the external references on a given website. 

Prerequesites:
This project requires Python 3 and a normal user account. 

Usage:
To run this program, it is necessary to run it through the command line. 
The program should be run by typing 'python3 hw1.py' followed by an http or https web address. 
Example: 'python3 hw1.py https://www.rit.edu





